# Scrape Charts

Follow the steps completed in test_scraper.py (located in the tests folder). The virtual environment does not need to be activited, but the import statements probably appear slightly differently, however comments will rectify your confusion on the correct string to paste.
